<?php include 'datalayer.php';
$conn = connectie();
$result = fetchalllocations($conn);  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locatie Toevoegen</title>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <label for="name">Voeg een locatie toe:</label>
  <input type="text" id="name" name="name" value=""><br>
 <?php 
    if(isset($_POST["name"])){
      $name = ($_POST["name"]);
      $sql = 'INSERT INTO locations(name)
      VALUES(?)';
      $stmt = $conn->prepare($sql);
      $stmt->execute([$name]);
    }
  ?>
</form> 

<form action="locations.php">
    <input type="submit" value="Location pagina" />
</form>
</body>
</html>