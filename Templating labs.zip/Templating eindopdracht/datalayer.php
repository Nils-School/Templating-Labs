<?php
 

function connectie(){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "characters";
        $conn;
        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
            return $conn;
        }
        catch(PDOException $e)
            {
            echo "Error: " . $e->getMessage();
        }
    }
          //connectie 
function fetchallcharacters($conn){
        $result;
        $stmt = $conn->prepare("SELECT * FROM characters");
            $stmt->execute();
            $result = $stmt->fetchAll();
            return $result;
}



function fetchcharacterid($id){
    $result;
    $stmt = $conn->prepare("SELECT * FROM `characters` WHERE id = " + $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
}

function countcharacter($result){
    return count($result);
}

function fetchalllocations($conn){
    $result;
    $stmt = $conn->prepare("SELECT * FROM locations");
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;      
}

function countlocations($result){
    return count($result);
}
function createoption($id, $name){
    echo "<option value='$id'> $name </option>";
 }

function updatelocation($conn, $id, $currentcharacterid ){
    $sql = "UPDATE characters  
    SET location = $id
    WHERE id =$currentcharacterid";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
  }

function createlocations($id, $name)
{ 
   
echo "
<a href='locationdeleten.php?id=$id'>Verwijder </a>$name </br>
";
}



      ?>
       