<?php 
include 'datalayer.php';
 $conn = connectie();
 $result = fetchalllocations($conn);  
 $currentcharacterid = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<header> 
</header>
<body>
<h1>Weet je zeker dat je deze locatie wilt verwijderen?</h1>
<form method="post">
    <input type="submit" value="Ja!">
    <?php 
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            deletelocation($conn, $currentcharacterid);
        }
        ?>
    </form> 

<form action='locations.php'>
<input type="submit" value="Nee!">
    </form>


    <?php
   

if($_SERVER["REQUEST_METHOD"] == "POST"){
    deletelocation($conn, $currentcharacterid);
  }
  
function deletelocation($conn, $currentcharacterid){
    $sql = "DELETE FROM locations WHERE id='$currentcharacterid'";
    $stmt = $conn->prepare($sql);
    $stmt->execute(); 
    header("Location: locations.php");  
      }


  ?>
</form>







</body>
</html>