<?php 
include 'datalayer.php';
$conn = connectie();
$result = fetchalllocations($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locations</title>
</head>
<body>
    <header>
    <h1>Alle <?php echo countlocations($result);?> locations uit de database</h1> 
    </header>
    <?php  
  for ($i=0; $i < count($result); $i++) { 
   $data = $result[$i];
  createlocations($data["id"],$data["name"]);
     }
?>
    <form action="index.php">
    <input type="submit" value="Terug naar hoofd pagina" />
</form>
<form action="locationtoeven.php">
    <input type="submit" value="Voeg een locatie toe" />
</form>

</body>
</html>