<?php include'datalayer.php' ;
   $conn = connectie();
   $location = fetchalllocations($conn);
   $currentcharacterid = $_GET["id"];
   if($_SERVER["REQUEST_METHOD"] == "POST"){
     $id=$_POST["locatie"];
    updatelocation($conn, $id, $currentcharacterid);
    var_dump($id);
  }
?>
<form method="post" >
  <label><b>Huidige Locatie:</b></label>
  <select name="locatie">
  <?php 
foreach($location as $option){
  createoption($option['id'], $option['name']);
  }
?>
  </select>
  <input type="submit" value="update">
</form>

